#' @title FILES_info
#'
#' @description This function give names's structure of CMIP5 output files.Takes path of working directory
#'List all CMIP5 files in a directory treeanalyzing file names to give information (8 or 9)
#'such as experience, template and variable names, etc.
#'
#'@usage FILES_info(path='.', recursive=TRUE)
#'
#'\file{FILES_info} has a certains subfunctions
#'@param path acces at working directory
#'@param recursive Should the list be recurred in the directories ?
#'
#'@return data.frame containing the following structure in horizontal :
#'
#'  \item{FILES_info}{Full file name, path included}
#'  \item{variable}{File's variables}
#'  \item{domaine}{File's domain}
#'  \item{model}{Model that produise file}
#'  \item{experiment}{File's expérience}
#'  \item{ensemble}{File's ensemble}
#'  \item{time}{year some times it's month (give the file's range}
#'  \item{size}{File's size, in kilo-octets}
#'
#'For more supplementary information about CMIP5, name's structure and description :
#'
#'\url{http://cmip-pcmdi.llnl.gov/cmip5/data_description.html}
#'
#' @example
#'\dontrun{
#'FILES_info ()
#'FILES_info ('. ', récursif = FAUX)
#'}
#'
#' @export 'FILES_info ('. ', récursif = FAUX)
#'
#'@author LUKABWE KASONGO JOSUE \email{josuelukabwe@gmail.com} and SILMANE TAIBI \email{slimanetaibi@gmail.com}




FILES_info<- function(path='.', recursive=TRUE) { assert_that<-assertthat::assert_that
  # assert_that(is.dir(path))
  # assert_that(is.readable(path))
  # assert_that(is.flag(recursive))

  # Select all nc files in the work directory
  file_full <- list.files(path=".", pattern='nc$',
                          full.names=TRUE, recursive=TRUE)
  # Check the nc files's presence to processVérifiez qu'il y a des fichiers nc à traiter
  if(!length(file_full)) {
    warning('No NetCDF files found')
    return(NULL)
  }

  # Replaces the occurrence .nc found in the file names,
  file_short <- gsub(".nc$", "", basename(file_full))

  # Deconcatenate characters's files according to the CMIP5 writing style
  # ... Is orded by : variable_domain_model_experiment_ensemble_time
  # ... ou variable_domain_model_experiment_ensemble. Le premier exemple
  # ... Contains 6 and 5 identifiers respectively.
  file_info <- strsplit(file_short, split='_')



  # Get number of string identifiers in filenames
  size_info <- unlist(lapply(file_info, length))
  # Mark those that match the expected number (8 or 9)
  valid <- size_info %in% c(8,9)

  # Delete files that don't have the expected number of string identifiers
  if(!all(valid)) {
    warning('Fichiers inattendus (pas correctement formatés). Couper les fichiers suivants de la liste: ', file_full[!valid])
    file_full <- file_full[valid]
    file_short <- file_short[valid]
    file_info <- file_info[valid]
    size_info <- size_info[valid]
    if(length(file_full) == 0) {
      warning('pas de fichiers.')
      return(NULL)
    }
  }

  # Extract size of each file
  sizeInfo <- unlist(lapply(file_full, function(x) { paste0(round(file.info(x)$size/1024), "K") }))

  # Process files separately, and then merge the frames of data beacause some files has 8 or 9 characters

  # Process fixes variables
  if(any(size_info == 8)) {
    info9 <- t(as.data.frame(file_info[size_info == 8], row.names=NULL))
    info9 <- cbind(info9, rep('', length=sum(size_info == 8)))
    info9 <- data.frame(#path=dirname(file_full[size_info == 8]),
      name_file=file_short[size_info==8],
      info9,
      size=sizeInfo[size_info==8],
      row.names=NULL)
  } else {
    info9 <- NULL
  }

  # Process relatives variables (exemple: tas)
  if(any(size_info == 9)) {
    info10 <-  t(as.data.frame(file_info[size_info==9], row.names=NULL))
    info10 <- data.frame(#path=dirname(file_full[size_info == 9]),
      name_file=file_short[size_info==9],
      info10,
      size=sizeInfo[size_info==9],
      row.names=NULL)
  } else {
    info10 <- NULL
  }
  dd<-lapply(info10, as.character)



  # Merge all variables

  file_info.df <- rbind(info9, info10)


  names(file_info.df) <- c('name', 'variable', 'domain', 'model', 'experiment', 'ensemble','RCmodel', 'version', 'duree', 'time', 'size')
  file_info.df <- data.frame(lapply(file_info.df, as.character),
                             stringsAsFactors=FALSE)


  return(file_info.df)

} # Get files informations
ficier<-FILES_info()
ficier
#library(dplyr)
library(dplyr, warn.conflicts = FALSE)
by_cyl <- ficier %>% group_by(time)

#sélect each variable name , exemple pr:
Select_par <- function(x){
  # La fonction "cat" imprime dans la console
  # "\n" provoque un retour de chariot
  #print("Parameter", x, "\n");+
  b <- by_cyl%>%filter(variable==x) #subset(by_cyl,by_cyl$variable=="x","name");
  #b<-as.data.frame(b)
  return(b)
}
Select_par("tas")
