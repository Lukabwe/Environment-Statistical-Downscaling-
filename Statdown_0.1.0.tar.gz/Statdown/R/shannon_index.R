#' @title shannon index
#'
#' @description This function compute the Shannon index on the columns of data frame
#
#'@param df  Data.frame of data to compute
#'
#'@return data.frame
#'  \item{shanonn}{Shannon index associated with classes}
#'
#' @examples
#'\dontrun{
#'x<-matrix(0:18,nrow = 6)
#'shannon (x)
#'
#'y<-rpois(10,6)
#'shannon(y)
#'}
#'
#' @export shannon()
#'
#'@author LUKABWE KASONGO JOSUE \email{josuelukabwe@gmail.com} and SILMANE TAIBI \email{slimanetaibi@gmail.com}


shannon <- function(df){
  if(!is.data.frame(df)){
    df <- data.frame(df)
      }
  interm <- function(y) {
    resi <- sapply(y, function(u) if(u != 0)
      (- (u / sum(y)) * log(u / sum(y))) else 0)
    return(sum(resi))
  }
  res <- apply(df, 2, interm)
  result<-as.data.frame(res)
  print(" shannon index is :")
  return(res)
}
