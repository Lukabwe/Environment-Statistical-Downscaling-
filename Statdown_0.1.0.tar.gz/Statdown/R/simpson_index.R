#' @title simpson index
#'
#' @description This function compute the simpson index on the columns of data frame
#
#'@param df  Data.frame of data to compute
#'
#'@return data.frame
#'  \item{simpson}{Simpson index associated with classes}
#'
#' @example
#'\dontrun{
#'x<-matrix(0:18,nrow = 6)
#'simpson (x)
#'
#'y<-rpois(10,6)
#'simpson(y)
#'}
#'
#' @export simpson()
#'
#'@author LUKABWE KASONGO JOSUE \email{josuelukabwe@gmail.com} and SILMANE TAIBI \email{slimanetaibi@gmail.com}

simpson <- function(df){
  if(!is.data.frame(df)||!is.list(df)){
    df <- data.frame(df)
  }
  interm <- function(y) {
   resi <- sapply(y, function(u) if(u != 0)
      ((u / sum(y))^2) else 0)
    return(1-sum(resi))
  }
index <- apply(df, 2, interm)
result<-as.data.frame(index)
print("Simpson index is :")
return(index)
}

