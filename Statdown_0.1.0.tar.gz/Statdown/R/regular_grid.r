#################################################################################################################
#' @title grid_region
#'
#' @description This function create a "blank" grid that contains regular cells
#'from n_row*n_col meter^2 in a WGS84 CRS, covering definited region .
#'
#'@usage grid_region(xmin,ymin,n_row,n_col,resolution,crs)
#'
#'@param xmin  minimum longitude of the grid (left)
#'@param ymin  Minimum latitude of the grid (left)
#'@param nrow  Number of grid lines
#'@param ncol  Number of grid columns
#'@param resolution Resolution of the grid.
#'@param crs Reference Coordinate Systems define the grid projection
#'
#'@note The user must define the crs with the unit, otherwise the default unit will be used [degre]
#'
#'@return data.frame
#'  \item{grid}{Raster grid on the region defined}
#'
#' @example
#'\dontrun{
#' crs<-CRS("+proj=longlat +datum=WGS84 +no_defs")
#' grid_region(12.6466,-13.0939,100,100,1,crs)
#'
#'}
#'
#' @export grid_region(xmin,ymin,n_row,n_col,resolution,crs)
#'
#'@author LUKABWE KASONGO JOSUE \email{josuelukabwe@gmail.com} and SILMANE TAIBI \email{slimanetaibi@gmail.com}


grid_region<-function(xmin,ymin,n_row,n_col,resolution,crs){

  require(rgdal)
  require(raster)
  require(sp)
#assertthat::assert_that(is.character(crs) & length(crs)==1)
  #global_crs <- CRS("+init=epsg:4326")
  global_crs <-crs
crs_def<-sp::CRS("+proj=longlat +datum=WGS84 +no_defs")
# I'm going to make a n_row*n_col  grid of *approximate* resolution"m" squares with
# origin at this lat-long point:
  origin = SpatialPoints(cbind(xmin,ymin),global_crs)

# I have to convert that origin point to EU projection coordinates,
# which are in metres:


  origin_region <- spTransform(origin, crs_def)

# and I'm going to specify my extent. I've rounded the origin
# coordinates to the nearest
  xmax<-xmin + n_row*resolution
  ymax<-ymin + n_col*resolution
  zone <-  raster::extent(xmin, xmax, ymin, ymax)

  # now I define a raster based on that extent:
  r = raster(zone)

  # and tell it it has "10mm" square cells:
  res(r)<- c(resolution,resolution)
  # now I can fill it with n_row*n_col data values:
  r[] <- runif(n_row*n_col)

# set its projection:
projection(r)=crs_def

# and plot it.
plot(r)

# I can save it as a GeoTIFF:
writeRaster(r,"Tchilalou.tif")
}

