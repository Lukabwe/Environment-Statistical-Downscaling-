#' @title cir_declin
#'
#' @description This function compute declination using the method taken from Campbell & Norman's book.
#'
#' @usage cir_declin(Jday)
#'
#'@param Jday  Vector of  Julian dates or days of the year [day]
#'
#'@return
#'  \item{data.frame}{Day and associated declination}
#'
#'  @references “An introduction to Environmental Biophysics”, G..S.
#'  Campbell & J.M. Norman, New York: Springer, 2nd ed., 1998
#'
#' @example
#'\dontrun{
#'Jday<-seq(31:60)
#'a<-as.vector(Jday)
#'cir_declin(a)
#'}
#'
#' @export cir_declin (Jday)
#'
#'@author LUKABWE KASONGO JOSUE \email{josuelukabwe@gmail.com} and SILMANE TAIBI \email{slimanetaibi@gmail.com}


# declination for circular orbit

cir_declin<-function(Jday){
if(!is.vector(Jday))
stop(paste("Jday must be a vector"))
for(i in Jday){
cir_declin<-23.45*sin( 360/365 *(284+Jday) *pi/180)
}
d<-cbind(Jday,cir_declin)
d<-as.data.frame(d)
return(d)
}


