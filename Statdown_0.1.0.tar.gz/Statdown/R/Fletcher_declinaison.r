#' @title Fle_declin
#'
#' @description This function compute declination using the Flectcher method.
#'
#' @usage Fle_declin(Jday)
#
#'@param Jday  Vector of  Julian dates or days of the year [day]
#'
#'@return
#'  \item{data.frame}{Day and associated declination}
#'
#'@references “Solar Declination”, D. Fletcher, 2007, http://en.wikipedia.org/wiki/Declination
#'
#' @example
#'\dontrun{
#'Jday<-seq(31:60)
#'a<-as.vector(Jday)
#'Fle_declin(a)
#'}
#'
#' @export Fle_declin(Jday)
#'
#'@author LUKABWE KASONGO JOSUE \email{josuelukabwe@gmail.com} and SILMANE TAIBI \email{slimanetaibi@gmail.com}

Fle_declin<-function(Jday){
if(!is.vector(Jday))
stop(paste("Jday must be a vector"))
for(i in Jday){

Fle_declin <- 23.45*sin( 2*pi/365*(284+Jday))
}

d<-cbind(Jday,Fle_declin)
d<-as.data.frame(d)
return(d)

}



