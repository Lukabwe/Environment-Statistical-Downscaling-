#' @title control_horizon
#'
#' @description This function checks the continuous periods in the CMIP5 files of the chosen horizon.
#'
#' @usage control_horiz(horizon)
#'
#'
#'\file{FILES_info} has a certains subfunctions
#'@param horizon  climatic horizon chosen
#'
#'@return data.frame containing the following structure in horizontal :
#'
#'  \item{Name}{Full file name}
#'  \item{variable}{File's variables}
#'  \item{domaine}{File's domain}
#'  \item{model}{Model that produise file}
#'  \item{experiment}{File's expérience}
#'  \item{ensemble}{File's ensemble}
#'  \item{time}{year some times it's month (give the file's range}
#'  \item{size}{File's size, in kilo-octets}
#'
#'
#' @details  This function calls \code{\link{getFILES_info}} to scan a directory tree,
#' and then examines the time data in these filenames. These time signatures
#' will be concatenated and an 'allHere' flag returned.
#'
#' @note gfhgf
#'
#' @note dfhdgh
#'
#'
#'@examples
#'\dontrun{
#'control_horiz(horizon="2040")
#'}
#'\dontrun{
#'control_horiz(horizon="2020")
#'}
#'
#'@export control_horiz(horizon)
#'
#'@author LUKABWE KASONGO JOSUE \email{josuelukabwe@gmail.com} and SILMANE TAIBI \email{slimanetaibi@gmail.com}
#'
#'control_horiz(horizon="2040")
#'horizon="2040"

control_horiz <- function(horizon) {
    jj<-0
    assert_that<-assertthat::assert_that
    hor=as.numeric(horizon)
	  f<-FILES_info()
    # Sanity checks
    assert_that(length(horizon)==1 & is.character(horizon))
    ddplyFields <- c("time","experiment")
    assert_that(all(ddplyFields %in% colnames(f)))
    assert_that("time" %in% colnames(f))
    dff<-NULL
    # Break up data frame, process and check time field, and return result
    result <- data.frame()
    splitter <- apply( f[, ddplyFields], 1, paste, collapse="-" )
    for(i in unique(splitter)) {
      jj<-jj+1
        x <- f[splitter==i,]

        # split the time signiture
        curCombo <- matrix(unlist(strsplit(as.character(x$time), '-')),
                           ncol=2, byrow=TRUE)

        # Find the starting and ending decimal year
        startYear <- as.numeric(substr(curCombo[,1], 1, 4))
        endYear <- as.numeric(substr(curCombo[,2], 1, 4))

        # pull the time step from the domain name
        if(all(x$domain %in% 'fx')) { # fixed
            # don't even process fixed files
            next
        } else if(all(grepl('mon', x$domain))) { # monthly
            timeStep <- 1/12
            # convert to decimal years
            startYear <- startYear+(as.numeric(substr(curCombo[,1], 5, 6))-1)/12
            endYear <- endYear + (as.numeric(substr(curCombo[,2], 5, 6))-1)/12
        } else if(all(grepl('yr', x$domain))) { # annual
            timeStep <- 1
        } else {
            # we can not process sub-monthly time scales because of not standard
            #... year lengths. The user must check the strings by hand.
            timeStep <- NA
        }

        if(is.na(timeStep)) {
            allHere <- NA
        } else {
            # Figure out the target date for the start of the next file
            nextYear <- endYear + timeStep
        }

        # One file is always complete
        if(length(startYear) == 1) {
            allHere <- TRUE
            # If multiple files, shift indexes to compare the start/stop values
        } else if( !is.na(timeStep) & length(startYear) > 1) {
            startIndex <- c(2:length(startYear))
            endIndex <- c((2:length(startYear))-1)
            allHere <- all(abs(nextYear[endIndex]-startYear[startIndex]) < 1e-6)
        }

        # return answering data frame which contains
        #   yrStr - All orginal year strings for reference (useful if something is wrong).
        #   allHere - boolean saying if the strings match up
        #   startDate - earliest time stamp
        #   endDate - latest time stamp
        result <- rbind(result, cbind(
            x[1, ddplyFields],
            data.frame(yrStr=paste(x$time, collapse=';'),
                       allHere=allHere,
                       startDate=min(startYear),
                       endDate=max(endYear),
                       files=length(startYear))
        ))

    }
    jjj<-0
    h<-which( result$endDate==horizon )
    {
      jjj=jjj+1

	   h<-which( result$endDate==hor )
 hh<-which( result$endDate==hor+10 )
    dfff<-f[c(h,hh),]
    dff <- data.frame(lapply(dfff, as.character),
                      stringsAsFactors=FALSE)

    }


   if(length(dff[,1]) == 0){
      warning('No file(s) for this horizon was found, returning NULL')
     dff<-NULL

     }
   return(dff)
}


