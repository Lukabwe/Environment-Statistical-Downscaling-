#' @title Fourier_series_d
#'
#' @description This function compute declination using the Fourier series
#' representation of the position of the sun.
#'
#' @usage Fourier_declin(Jday)
#
#'@param Jday  Vector of  Julian dates or days of the year [day]
#'
#'@return
#'  \item{data.frame}{Day and associated declination}
#'
#'@references Fourier series representation of the position of the Sun”, J.W. Spencer, Search Vol 2 (5) 172, 1971.
#'
#' @example
#'\dontrun{
#'Jday<-seq(31:60)
#'a<-as.vector(Jday)
#'Fourier_sd(a)
#'}
#'
#' @export Fourier_sd(Jday)
#'
#'@author LUKABWE KASONGO JOSUE \email{josuelukabwe@gmail.com} and SILMANE TAIBI \email{slimanetaibi@gmail.com}

Fourier_sd<-function(Jday){
if(!is.vector(Jday))
stop(paste("Jday must be a vector"))
for(i in Jday){
g<-2*pi/365*(Jday-1)
Fourier_d<-180/pi*(.006918-.399912*cos(g)+.070257*sin(g)-.006758*cos(2*g)+.000907*sin(2*g)-
.002697*cos(3*g)+.00148*sin(3*g))
}
d<-cbind(Jday,Fourier_d)
d<-as.data.frame(d)
return(d)
}

Jday<-seq(1:365)
a<-as.vector(Jday)
Fourier_sd(a)
