#'@title dis_earth Earth distance between two points.
#'
#'@description This function compute dstance between two points.
#'
#'@usage dis_earth(lon1, lat1, lon2, lat2)
#
#'@param lon1  longitude of first point
#'@param lat1  latitude of first point
#'@param lon2  longitude of second point
#'@param lat2  latitude of  second point
#'
#'@return
#'  \item{Distance}{Distance between in kilometer}
#'
#' @example
#'\dontrun{
#'Likasi:
#'lon1<-26.73333, lat1<- -10.98139
#'Lubumbashi :
#'lon2<-27.47938, lat2<- -11.66089
#'
#'dis_earth(lon1, lat1, lon2, lat2)
#'}
#'
#'@export dis_earth(lon1, lat1, lon2, lat2)
#'
#'@author LUKABWE KASONGO JOSUE \email{josuelukabwe@gmail.com} and SILMANE TAIBI \email{slimanetaibi@gmail.com}
#'

dis_earth<- function (lon1, lat1, lon2, lat2) {

  rad <- pi/180
  a1 <- lat1 * rad
  a2 <- lon1 * rad
  b1 <- lat2 * rad
  b2 <- lon2 * rad
  dlon <- b2 - a2
  dlat <- b1 - a1
  a <- (sin(dlat/2))^2 + cos(a1) * cos(b1) * (sin(dlon/2))^2
  c <- 2 * atan2(sqrt(a), sqrt(1 - a))
  R <- 6378.145
  d <- R * c
  print("distance between this two points in km is")
  return(d)
}
