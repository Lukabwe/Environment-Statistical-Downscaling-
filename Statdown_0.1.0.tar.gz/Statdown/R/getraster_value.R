#'@title graster_dat
#'
#'@description This fonction extracts data on rasteur on the point of latitude and longitude coordinates
#'
#'@usage graster_dat(lon,lat,file=file.choose())
#'
#'@param lon vector of longitudes or longitude of the point we want to extract value(s).
#'
#'@param lat vector of longitudes or longitude of the point we want to extract value(s).
#'
#'@param file Choose a file interactively.
#'
#'@return \item{value(s)}{Data contained in the raster }
#'
#'@note File must be in format tif.
#'
#'@examples
#'\dontrun{
#'lon<-10
#'lat<--15
#'get_indice_E(lon,lat,file=file.choose())
#'
#'lon<-c(19.24663,19.68663,24.52663,24.96663)
#'lat<-(> a<-c(4.9461,4.9461,4.9461,4.9461)
#'graster_dat(lon,lat,file=file.choose())
#'
#' }
#'
#' @export graster_dat()
#'
#'@author LUKABWE KASONGO JOSUE \email{josuelukabwe@gmail.com} and SILMANE TAIBI \email{slimanetaibi@gmail.com}

graster_dat <- function(lon,lat,file=file.choose())
  {
    # Extraction de la carte de l'indice E de Chave et al. (2014) de la valeur
    # de E au point de longitude 'lon' et latitude 'lat'

    library(raster)
    if(extension(file)==".zip") file <- suppressWarnings(unzip(file,exdir=tempdir(),overwrite=FALSE))
    Indice<-extract(raster(file),cbind(lon,lat),method="bilinear")
    return(Indice)
  }
