#'@title get_E_index
#'
#'@description This fonction extracts the climate index of Chave at the point of
#'             latitude and longitude coordinates
#'
#'@usage get_indice_E(lon,lat,file=file.choose())
#'
#'@param lon vector of longitudes or longitude of the point we want to extract value(s).
#'
#'@param lat vector of longitudes or longitude of the point we want to extract value(s).
#'
#'@param file Choose a file interactively.
#'
#'@return Chave E Index :
#'
#'  \item{E}{Climate index of Chave}
#'
#'@reference you can download data here :
#'
#'\url {http://chave.ups-tlse.fr/}
#'\url {http://chave.ups-tlse.fr/pantropical_allometry/E.tif.zip}
#'
#' @examples
#'\dontrun{
#'lon<-10
#'lat<--15
#'get_indice_E(lon,lat,file=file.choose())
#'
#'lon<-c(19.24663,19.68663,24.52663,24.96663)
#'lat<-(> a<-c(4.9461,4.9461,4.9461,4.9461)
#'get_indice_E(lon,lat,file=file.choose())
#'
#' }
#'
#' @export get_indice_E()
#'
#'@author LUKABWE KASONGO JOSUE \email{josuelukabwe@gmail.com} and SILMANE TAIBI \email{slimanetaibi@gmail.com}

get_indice_E <-
  function(lon,lat,file=file.choose())
  {
    # Extraction de la carte de l'indice E de Chave et al. (2014) de la valeur
    # de E au point de longitude 'lon' et latitude 'lat'

    library(raster)
    if(extension(file)==".zip") file <- suppressWarnings(unzip(file,exdir=tempdir(),overwrite=FALSE))
    Indice<-extract(raster(file),cbind(lon,lat),method="bilinear")
    print ("The Chave climate index E at the point is :")
    return(Indice)
  }
