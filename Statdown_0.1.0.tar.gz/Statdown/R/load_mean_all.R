#'@title   load_mean_all         Load mean by variable by models
#'
#'@description   This function loads .nc files of each variable for a given domain and for a given experiment
#'
#'@usage load_mean(variable, experiment, domain, model, path, recursive=TRUE, verbose=FALSE, force.ncdf=FALSE,yearRange=NULL, ZRange=NULL)
#'
#'@param  variable  Weather variable
#'@param  experiment Experiment of this variable either historical or senario rcp
#'@param  domain Geographical domain
#'@param  model Global climate model
#'@param  path Path acces at working directory recursive
#'@param  recursive
#'@param  verbose Boolean for verbosity. When TRUE ...
#'@param  force.ncdf Boolean for using ncdf or ncdf4 package. When TRUE, it's mean you don't prefer to use 'ncdf' package, instead of ncdf4.
#'
#'@value mean
#'\ item {mean} {Mean of times serie of weather variable}
#'@export load_mean_all(variable,experiment,domain,model,path='.',
#'recursive=TRUE, verbose=FALSE, force.ncdf=FALSE,yearRange=NULL, ZRange=NULL)
#'
#'@examples
#'\dontrun{
#'load_mean (variable='tas',experiment='rcp45',domain='AFR-44',model= 'ICHEC-EC-EARTH',path='.', recursive=TRUE, verbose=FALSE, force.ncdf=FALSE,yearRange=NULL, ZRange=NULL)
#'}
#'
#'@note This function laod mean by variable of all models present
#'
#'@author LUKABWE KASONGO JOSUE \email{josuelukabwe@gmail.com} and SILMANE TAIBI \email{slimanetaibi@gmail.com}






load_mean_all <- function(variable,experiment,domain,model,
                         path='.', recursive=TRUE, verbose=FALSE, force.ncdf=FALSE,
                         yearRange=NULL, ZRange=NULL) {

  # Sanity checks - make sure all parameters are correct class and length

  assert_that<-assertthat::assert_that
  abind<-abind::abind
  assert_that(length(variable)==1 & is.character(variable))
  assert_that(length(model)==1 & is.character(model))
  assert_that(length(experiment)==1 & is.character(experiment))

  assert_that(length(domain)==1 & is.character(domain))
#  assert_that(is.dir(path))
  #  assert_that(is.readable(path))
  assert_that(is.flag(recursive))
  assert_that(is.flag(verbose))
  assert_that(is.flag(force.ncdf))
  assert_that(is.null(yearRange) | length(yearRange)==2 & is.numeric(yearRange))
  assert_that(is.null(ZRange) | length(ZRange)==2 & is.numeric(ZRange))

  # We prefer to use the 'ncdf4' package, but if not installed can use 'ncdf'
  if(force.ncdf) {
    warning('force.ncdf is ignored now. ncdf4 is a required package')
  }
  requireNamespace('ncdf4', quietly=!verbose)
  .nc_open <- ncdf4::nc_open
  .ncatt_get <- ncdf4::ncatt_get
  .ncvar_get <- ncdf4::ncvar_get
  .nc_close <- ncdf4::nc_close


  # List all files that match specifications
  fileList <- list.files(path=path, full.names=FALSE)

  # Match file names with valid CMIP5 patterns:
  # ...variable_domain_model_experiment_ensemble followed by either
  # ...a '_' or a '.' depending on whether a time period is specified or not.
  # ...Note that the '[_\\.]' match differentiates between
  # ...ensembles like 'r1i1p1' and 'r1i1p11', an unlikely but possible case.
  fileLists <- fileList[grepl(pattern=sprintf('^%s_%s_%s_%s.*\\.nc$',
                                              variable,
                                              domain,model,experiment),
                              basename(fileList))]

 if(length(fileLists)==0) {
  # ...warning(paste("Could not find any matching files for",
  # ...   variable, domain, experiment))
return(NULL)
}

  # Get the domains of all files we want to load. Recall CMIP5 naming
  # ...conventions:variable_domain_model_experiment_ensemble_time.nc
  # ...
  domainCheck <- unname(vapply(unlist(fileLists),
                               function(x) { unlist(strsplit(basename(x), '_'))[2] },
                               FUN.VALUE=''))

  # Check that we are only loading one domain. We check this before checking
  # other CMIP5 specifications because 'fx' domains will split on '_' to a
  # different number of strings then temporal domains.
  if(length(unique(domainCheck)) > 1) {
    stop('Domain is not unique: [', paste(unique(domainCheck), collapse=' '), ']\n')
  }

  # Get the number of pieces of CMIP5 information strings
  numSplits <- length(unlist(strsplit(basename(fileLists[1]), '_')))

  # Split all file names based on '_' or '.'
  cmipName <- unname(vapply(unlist(fileLists),
                            function(x) { unlist(strsplit(basename(x), '[_\\.]')) },
                            FUN.VALUE=rep('', length=numSplits+1)))

  # List what order the files appear in the name, for CMIP5 this will be:
  # ...variable_domain_model_experiment_ensemble_time.nc Note that we
  # ...aren't interested in checking the time string
  checkField <- list(variable=1, domain=2, model=3, experiment=4)

  # Go through and make sure that we have unique variable, domain, model,
  # ...experiment, and ensemble strings for the set of files we are trying
  # ...to load. We want to avoid trying to load a file from ModelA and ModelB
  # ...as one cmip5data structure here. Also set the appropreate variables
  # ...so we can identify the cmip5data object correctly.
  for(checkStr in names(checkField)) {
    # Pull all unique strings
    tempStr <- unique(cmipName[checkField[[checkStr]],])
   for (gf in 1:length(tempStr) ) { # there should only be one!
     #   stop('[',checkStr, '] is not unique: [', paste(tempStr, collapse=' '), ']\n')

      # Set a variable by the field name to the correct string for
      # ...this ensemble. For example there is now a variable
      # ...'variable' in the workspace containing the correct string
      # ...extracted from the first position of the file name.
      eval(parse(text=paste(checkStr, '[',1,'] <- "', tempStr[1], '"', sep='')))
    }
  }

  # Go through and load the data
  val <- c()

  val10 <- c()
  # # variable to temporarily hold main data
  timeRaw <- c()
  timeArr <- c()
  ZUnit <- NULL
  valUnit <- NULL
  loadedFiles <- c()

  # Note that list.files returns a sorted list so these file should already
  # be in temporal order if the ensemble is split over multiple files.

  for(fileStr in fileLists) {

    if(verbose) cat('Loading', fileStr, "\n")
    text=paste(path, fileStr, sep='')


    nc <- .nc_open(fileStr , write=FALSE)



    # Get variable names available
    varNames <- unlist(lapply(nc$var, FUN=function(x) { x$name }))

    # Get dimension names for 'variable'
    dimNames <- unlist(lapply(nc$var[[variable]]$dim, FUN=function(x) { x$name }))
    if(verbose) cat("-", variable, "dimension names:", dimNames, "\n")
    assert_that(length(dimNames) %in% c(1, 2, 3)) # that's all we know

    # Most, but not all, files have longitude and latitude. Load if available.
    lonArr <- NULL
    lonUnit <- NULL
    latArr <- NULL
    latUnit <- NULL
    if(length(dimNames) > 1) {
      # If 'lon' and 'lat' are available, use those. Otherwise load
      # whatever is specified by the main variable's dimensionality
      # TODO: this is a temporary (?) hack re issue #96
      if('lon' %in% varNames) dimNames[1] <- 'lon'
      if('lat' %in% varNames) dimNames[2] <- 'lat'

      lonArr <- .ncvar_get(nc, varid=dimNames[1])
      lonUnit <- .ncatt_get(nc, dimNames[1], 'units')$value
      lonLen <- ifelse(length(dim(lonArr)) > 1, dim(lonArr)[1], length(lonArr))

      latArr <- .ncvar_get(nc, varid=dimNames[2])
      latUnit <- .ncatt_get(nc, dimNames[2], 'units')$value
      latLen <- ifelse(length(dim(latArr)) > 1, dim(latArr)[1], length(latArr))

      # Some models provide 1-D arrays, some 2-D. Convert all to the latter
      if(length(dim(lonArr)) < 2) {
        lonArr <- array(lonArr, dim=c(lonLen, latLen))
      }
      if(length(dim(latArr)) < 2) {
        latArr <- array(rep(latArr, 1, each=lonLen), dim=c(lonLen, latLen))
      }
    }

    # Get the time frequency. Note that this should be related to
    # ...the domain (ie 'mon' should be the frequency of the domain 'Amon').
    # ...In theory we could extract this from the domain
    timeFreqStr <- .ncatt_get(nc, varid=0, "frequency")$value

    # Non-fixed files have a time dimension to deal with:
    if(! timeFreqStr %in% 'fx') {
      # Get the time unit (e.g. 'days since 1860')
      timeName <- dimNames[length(dimNames)]
      timeUnit <- .ncatt_get(nc, timeName, 'units')$value
      # Get the type of calendar used (e.g. 'noleap')
      calendarStr <- .ncatt_get(nc, timeName, 'calendar')$value
      calendarUnitsStr <- .ncatt_get(nc, timeName, 'units')$value

      # Extract the number of days in a year
      if(grepl('^[^\\d]*\\d{3}[^\\d]day', calendarStr)) {
        calendarDayLength <- as.numeric(regmatches(calendarStr,
                                                   regexpr('\\d{3}', calendarStr)))
      } else {
        calendarDayLength <- 365
      }

      # Extract the year we are referencing in calendar
      # Set the default to year 1, month 1, day 1, hour 0, min 0, sec 0
      defaultCalendarArr <- c(1, 1, 1, 0, 0, 0)

      # Split the calandar unit string based on a '-', space, or ':'
      # ...this allows us to deal with YYYY-MM-DD hh:mm:ss, YYYY-MM-DD, or
      # ...YYYY-M-D
      calendarArr <- unlist(strsplit(calendarUnitsStr, split='[- :]'))

      # Check that the time is going to be in days otherwise latter
      # ...calculations for time array break


      # extract just the digits
      calendarArr <- as.numeric(calendarArr[grepl('^\\d+$', calendarArr)])

      # swap the default values with the extracted values, we assume
      # ... that years are listed before months, before days, and so on
      temp <- defaultCalendarArr
      temp[1:length(calendarArr)] <- calendarArr
      calendarArr <- temp

      # calculate the decimal starting year
      startYr <- sum((calendarArr - c(0, 1, 1, 0, 0, 0))
                     / c(1, 12, calendarDayLength, calendarDayLength*24,
                         calendarDayLength*24*60, calendarDayLength*24*60*60))

      # Load the actual time
      thisTimeRaw <- .ncvar_get(nc, varid=timeName)
      attributes(thisTimeRaw) <- NULL
      assert_that(!any(duplicated(thisTimeRaw)))

      # convert from days (we assume the units are days) to years
      thisTimeArr <- thisTimeRaw / calendarDayLength + startYr
    } else { # this is a fx variable. Set most things to NULL
      startYr <- NULL
      timeArr <- NULL
      timeUnit <- NULL
      calendarStr <- NULL
      calendarDayLength <- NULL
      calendarUnitsStr <- NULL
    dim(val) <- dim(val)[1:2]
      thisTimeRaw <- NULL
      thisTimeArr <- NULL
    }


    ndims <- nc$var[[variable]]$ndims
    start <- rep(1, ndims)
    count <- rep(-1, ndims)


    # Finally, load the actual data and its units
    vardata <- .ncvar_get(nc, varid=variable, start=start, count=count)
    tdim<-length(vardata[1,1,])
    xdim<-length(vardata[,1,1])
    ydim<-length(vardata[1,,1])
    vm<-NULL
    loadedFiles <- c(loadedFiles, basename(fileStr))

    for(pj in 1:12) {

      gg<-0
      v=0
          for(pi in seq(pj,tdim,12)){
            val<-vardata[,,pi]

            v=v+val

            gg<-gg+1
          }

      vm<-v/gg

      val10 <- abind(val10, vm, along=3)


    }




    .nc_close(nc)
  } # for filenames
  return(val10)
  # If nothing loaded...
  if(length(val10) == 0){
    warning('Nothing was found, returning NULL')
    return(val10)
  }
}



restoreMissingDims <- function(dims, dimNames, lonArr, latArr, ZArr, thisTimeRaw, verbose) {
  if(is.null(lonArr) | length(lonArr) == 1 ) {
    if(verbose) cat("- restoring dimension for lon\n")
    dims <- c(1, dims)
  }
  if(is.null(latArr) | length(latArr) == 1 ) {
    if(verbose) cat("- restoring dimension for lat\n")
    dims <- c(dims[1], 1, dims[2:length(dims)])
  }
  if(length(ZArr) == 1) {
    if(verbose) cat("- restoring dimension for Z\n")
    if(length(dims) >= 3)
      dims <- c(dims[1:2], 1, dims[3:length(dims)])
    else
      dims <- c(dims, 1)
  }
  if(length(thisTimeRaw) == 1) {
    if(verbose) cat("- adding extra dimension for time\n")
    dims <- c(dims, 1)
  }

  # At this point, we've restored all dimensions dropped due to length 1 issues
  # But we want all data moving through RCMIP5 to have four dimensions
  if(length(dims) == 1) {  # assume time only
    if(verbose) cat("- adding extra dimensions for lon, lat, Z\n")
    dims <- c(1, 1, 1, dims)
    dimNames <- c(NA, NA, NA, dimNames)
  } else if(length(dims) == 2) { # assume lon, lat
    if(verbose) cat("- adding extra dimensions for Z, time\n")
    dims <- c(dims, 1, 1)
    dimNames <- c(dimNames, NA, NA)
  } else if(length(dims) == 3) { # assume lon, lat, time
    if(verbose) cat("- adding extra dimension for Z\n")
    dims <- c(dims[1:2], 1, dims[3])
    dimNames <- c(dimNames[1:2], NA, dimNames[3])
  } else if(length(dims) == 4) { # assume lon, lat, Z, time
    # no change needed
  } else
    stop("Variable dimensions out of bounds!")

  list(dims=dims, dimNames=dimNames)
} # restoreMissingDimensions

