#'@title joviane_soiltex      USDA Soil texture triangle
#'
#'@description This fonction display a USDA soil texture triangle
#'  with optional grid, labels and soil texture points.
#'
#'@usage joviane_soiltex  (soiltexture, main = "Soil Texture Plot", pch = 1, col = "black",
#'soil.names = TRUE, soil.lines = TRUE, show.points = TRUE,show.clabels = FALSE,
#'show.grid = FALSE, show.legend = FALSE, col.names = "blue", col.lines = "grey",
#'bg.pch = "white", col.grid = "grey", lty.grid = 3)
#'
#'@param soiltexture Matrix of soil textures where each row is a soil sample and three
#'columns contain the proportions of the components sand, silt and clay in the range
#'0 to 1 or percentages in the range 0 to 100.
#'
#'@param main The title of the soil texture plot. Defaults to nothing.
#'
#'@param pch  Symbols to use in plotting values.
#'
#'@param col  Color of the symbols representing each value.
#'
#'@param soil.names Logical - whether to show the names of different soil types
#'within the soil triangle.
#'
#'@param soil.lines   Logical - whether to show the limits lines of different soil types
#'within the soil triangle
#'
#'@param show.points  Logical - whether to show differents points of soil texture
#'within the soil triangle
#'
#'@param show.clabels  Logical - whether to show differents points of soil texture
#'within the soil triangle
#'
#'@param show.grid  Logical - whether to display grid of textured triangle.
#'
#'@param show.legend  Logical - whether to display a legend.
#'
#'@param col.names   Color of the soil names. Defaults to blue.
#'
#'@param col.lines  Color of the boundary lines. Defaults to grey
#'
#'@param bg.pch   color of the points symbols when pch 21:25 are used; defaults to white
#'
#'@param col.grid  Color of the grid lines. Defaults to grey.
#'
#'@param lty.grid  Type of line for the grid. Defaults to dashed.
#'
#'@details soil.texture displays a triangular plot area on which
#'soil textures defined as proportions of sand, silt and clay can
#'be plotted. Optional grid, vertex labels, soil type divisions
#'and names may also be displayed. If a matrix of soil textures
#'is present, these will be plotted.
#'
#'@return data.frame including the following elements :
#'
#'  \item{names}{Names of all soiltexture inputed (rownames of data.frame)} and as colnames:
#'  \item{x,y}{Coordonates of positions of the soil types plotted if ‘soiltexture’ was included }
#'  \item{soil types}{All soil types in the soil texture triangle of data inputed}
#'
#'@note If the type of soil of the input data exists, the element ij (input, type of soil)
#' of the dataframe is equal to 1, otherwise 0.
#' @note In the input data soil texture proportions must be between zero and one
#'
#' @references Soil Survey Division Staff. 1993. Soil survey manual. Soil Conservation Service.
#' U.S. Department of Agriculture Handbook 18.
#'
#' @example
#'\dontrun{
#' sol4<-c(0.1,0.3,0.5)
#' sol3<-c(0.2,0.1,0.3)
#' sol5<-c(0.3,0.4,0.2)
#' sol6<-c(0.2,0.2,0.3)
#' sol7<-c(0.1,0.2,0.2)
#' sol8<-c(0.2,0.3,0.4)
#' sol1<-c(0.1,0.4,0.5)
#' sol2<-c(0.2,0.5,0.3)
#' soil.samples<-rbind(sol1,sol2,sol3,sol4,sol6,sol7,sol8)
#' colnames(soil.samples)<-c("clay","sand","silt")
#'
#' joviane_soiltex  (soil.samples)
#' }
#'
#' @export joviane_soiltex  (soiltexture, main="Soil Texture Plot", pch=1, col="black",soil.names=TRUE,
#'  soil.lines=TRUE,show.points=TRUE, show.clabels=FALSE, show.grid=FALSE, show.legend=FALSE,
#'  col.names="blue", col.lines="grey", bg.pch="white",col.grid="grey", lty.grid=3)
#'
#'@author LUKABWE KASONGO JOSUE \email{josuelukabwe@gmail.com} and SILMANE TAIBI \email{slimanetaibi@gmail.com}



joviane_soiltex  <- function(soiltexture, main="Soil Texture Plot", pch=1, col="black",
                    soil.names=TRUE, soil.lines=TRUE,
                    show.points=TRUE, show.clabels=FALSE, show.grid=FALSE, show.legend=FALSE,
                    col.names="blue", col.lines="grey", bg.pch="white",
                    col.grid="grey", lty.grid=3) {

  if(show.points) {
    ## error checking
    if(missing(soiltexture))
      stop("Usage: plot.soiltexture(soiltexture, pch=NULL, col=NULL, soil.names=FALSE, show.grid=FALSE)")
    if(!is.matrix(soiltexture))
      stop("Object soiltexture must be a matrix with at least three columns (for Sand, Silt, and Clay) and one row.")
    if(any(soiltexture > 1) || any(soiltexture < 0))
      stop("All soil texture proportions must be between zero and one.")
    if(any(abs(rowSums(soiltexture)-1) > 0.01))
      warning("At least one set of soil texture proportions does not equal one.")
  }

  oldpar<-par(no.readonly=TRUE)
  sin60<-sin(pi/3)
  par(xpd=TRUE)

  # create empty canvas to draw
  plot(0:1,type="n",axes=FALSE,xlim=c(0,1.1),ylim=c(0,1),
       main=main,xlab="",ylab="")

  if(soil.lines) {
    # boundary of clay with extensions
    x1<-c(0.275,0.352,0.6)
    x2<-c(0.415,0.8,0.7)
    y1<-c(0.55*sin60,0.4*sin60,0.4*sin60)
    y2<-c(0.275*sin60,0.4*sin60,0.6*sin60)
    segments(x1,y1,x2,y2, col=col.lines)
    # lower bound and divider of clay loam and silty clay loam
    x1<-c(0.415,0.661)
    x2<-c(0.863,0.6)
    y1<-c(0.275*sin60,0.275*sin60)
    y2<-c(0.275*sin60,0.40*sin60)
    segments(x1,y1,x2,y2, col=col.lines)
    # upper/lower bounds of sandy clay loam and divider with loam
    x1<-c(0.1755,0.1,0.3775)
    x2<-c(0.375,0.3775,0.415)
    y1<-c(0.35*sin60,0.2*sin60,0.2*sin60)
    y2<-c(0.35*sin60,0.2*sin60,0.275*sin60)
    segments(x1,y1,x2,y2, col=col.lines)
    # dividers sand, loamy sand and sandy loam
    x1<-c(0.05,0.075)
    x2<-c(0.15,0.3)
    y1<-c(0.1*sin60,0.15*sin60)
    y2<-c(0,0)
    # lower bounds of loam and upper bounds of silt
    segments(x1,y1,x2,y2, col=col.lines)
    x1<-c(0.377,0.44,0.5,0.8,0.86)
    x2<-c(0.44,0.537,0.638,0.86,0.94)
    y1<-c(0.2*sin60,0.077*sin60,0,0,0.12*sin60)
    y2<-c(0.077*sin60,0.077*sin60,0.275*sin60,0.12*sin60,0.12*sin60)
    segments(x1,y1,x2,y2, col=col.lines)
  }

  # construire un polygone argile
  x_clay <- c(0.4992748, 0.2768435 ,0.3527957, 0.6023527 ,0.7000055)
  y_clay<- c(0.8658220 ,0.4754509, 0.3466687, 0.3466687, 0.5197198)
  poly1 <- polygon(x_clay, y_clay, col = "red", border = "red")

  x_sandy_clay <-c(0.2768435, 0.1764782, 0.3744963)
  y_sandy_clay <-c( 0.4754509, 0.3023998 ,0.3023998)
  poly2 <- polygon(x_sandy_clay, y_sandy_clay, col = "pink", border = "red")

  x_sandy_clay_loam<-c(  0.1764782,0.1032387, 0.3826340, 0.4124724, 0.3744963);
  y_sandy_clay_loam<-c(   0.3023998 ,0.1736175, 0.1695931 ,0.2380086,0.3023998)
  poly3 <- polygon(x_sandy_clay_loam, y_sandy_clay_loam, col = "gray", border = "red")

  x_sandy_loam <-c(  0.10385493, 0.07985251, 0.30187494, 0.49989494, 0.54489948, 0.44288918, 0.37988282)
  y_sandy_loam <-c( 0.171572768,0.127077969, 0.001936348, 0.001936348, 0.065897621, 0.068678546,0.171572768 )
  poly4 <- polygon(x_sandy_loam, y_sandy_loam, col = "orange", border ="red")

  x_loamy_sand <-c( 0.076640361, 0.051837655,0.148568207,0.298624577)
  y_loamy_sand <-c(0.1298588938, 0.0881450201, 0.0019363477,0.0019363477)
  poly5 <- polygon(x_loamy_sand , y_loamy_sand , col = "pink", border = "red")

  x_sand <-c(0.051837655, 0.002232244 ,0.148568207)
  y_sand <-c(0.0881450201,0.0019363477,0.0019363477)
  poly6 <- polygon(x_sand, y_sand, col = "orange", border = "red")


  x_silt_loam <-c(0.6409092 ,0.8629316, 0.9409395, 0.8599313 ,0.7999252, 0.4968946)
  y_silt_loam <-c( 0.235534041, 0.238314965, 0.102049645, 0.102049645, 0.001936348,0.004717273)
  poly7 <- polygon(x_silt_loam, y_silt_loam, col = "yellow", border = "red")


  x_loam <-c(0.438759865,0.379233371 ,0.415197294, 0.6379089, 0.5388989)
  y_loam <-c(0.0658976208,0.1715727675,0.2383149655, 0.235534,0.0658976208)
  poly8 <- polygon(x_loam, y_loam, col = "red", border = "red")



  x_clay_loam <-c(0.6619113, 0.4128862, 0.3528801 ,0.6019052)
  y_clay_loam <-c( 0.2383150, 0.2383150, 0.3467710, 0.3467710)
  poly9 <- polygon(x_clay_loam, y_clay_loam, col = "gray", border = "red")



  x_silty_clay <-c(  0.6023527 ,0.7000055,0.8015944)
  y_silty_clay<-c(0.3466687, 0.5197198,  0.3466687)
  poly10 <- polygon(x_silty_clay, y_silty_clay, col = "yellow", border = "red")

  x_silt <-c( 0.8629316, 0.9409395, 0.9949449, 0.7969249)
  y_silt <-c(0.1020496447 , 0.1020496447 , 0.0047172726,  0.00417172726)
  poly11 <- polygon(x_silt, y_silt, col = "orange", border = "red")

  x_silty_clay_loam <-c(0.8015944,0.6023527,0.6639375, 0.864126268)
  y_silty_clay_loam <-c(0.3466687,0.3466687, 0.23553406,0.2355340406)
  poly12 <- polygon(x_silty_clay_loam, y_silty_clay_loam, col = "red", border = "red")


  if(soil.names) {
    # soil texture labels
    par(cex=0.8)
    text(0.5,0.57,"Clay", col=col.names)
    text(0.7,0.48*sin60,"Silty", col=col.names)
    text(0.7,0.44*sin60,"clay", col=col.names)
    text(0.72,0.35*sin60,"Silty clay", col=col.names)
    text(0.73,0.31*sin60,"loam", col=col.names)
    text(0.5,0.34*sin60,"Clay loam", col=col.names)
    text(0.28,0.43*sin60,"Sandy", col=col.names)
    text(0.27,0.39*sin60,"clay", col=col.names)
    text(0.27,0.3*sin60,"Sandy clay", col=col.names)
    text(0.27,0.26*sin60,"loam", col=col.names)
    text(0.25,0.13*sin60,"Sandy loam", col=col.names)
    text(0.13,0.075*sin60,"Loamy", col=col.names)
    text(0.17,0.035*sin60,"sand", col=col.names)
    text(0.065,0.035*sin60,"Sand", col=col.names)
    text(0.49,0.18*sin60,"Loam", col=col.names)
    text(0.72,0.14*sin60,"Silt loam", col=col.names)
    text(0.9,0.06*sin60,"Silt", col=col.names)
    par(cex=1)
  }

  # draw corner labels
  if(show.clabels) {
    text(0.5,0.9,"100% clay")
    text(-0.1,0,"100% sand")
    text(1.1,0,"100% loam")
  }

  ## the axis labels
  text(0.09,0.43,"% Clay")
  text(0.90,0.43,"% Silt")
  text(0.5,-0.1,"% Sand")

  # bottom internal ticks and labels
  bx1<-seq(0.1,0.9,by=0.1)
  bx2<-bx1-0.01
  by1<-rep(0,9)
  by2<-rep(0.02*sin60,9)
  segments(bx1,by1,bx2,by2)
  text(bx1,by1-0.03,as.character(rev(seq(10,90,by=10))))
  # left internal ticks and labels
  ly1<-bx1*sin60
  lx1<-bx1*0.5
  lx2<-lx1+0.02
  ly2<-ly1
  segments(lx1,ly1,lx2,ly2)
  text(lx1-0.03,ly1,as.character(seq(10,90,by=10)))
  # right internal ticks and labels
  rx1<-rev(lx1+0.5-0.01)
  rx2<-rx1+0.01
  ry1<-ly1-0.02*sin60
  ry2<-ly2
  segments(rx1,ry1,rx2,ry2)
  text(rx2+0.03,ry1+0.025,as.character(rev(seq(10,90,by=10))))

  # plot grid
  if(show.grid) {
    segments(bx2,by2,lx1,ly1, lty=lty.grid, col=col.grid)
    segments(lx2,ly2,rx2,ry2, lty=lty.grid, col=col.grid)
    segments(rev(rx1),rev(ry1),bx1,by1, lty=lty.grid, col=col.grid)
  }

  # draw triangle
  x1<-c(0,0,0.5)
  x2<-c(1,0.5,1)
  y1<-c(0,0,sin60)
  y2<-c(0,sin60,0)
  segments(x1,y1,x2,y2)

  # plot soil texture points
  if(show.points) {
    if(is.null(pch)) pch<-1:nrow(soiltexture)
    if(is.null(col)) col<-2:(nrow(soiltexture)+1)
    points(1-soiltexture[,1]+(soiltexture[,1]-(1-soiltexture[,2]))*0.5,
           soiltexture[,3]*sin60,pch=pch,col=col, bg=bg.pch)
  }

  # legend
  if(show.legend) {
    samplenames<-rownames(soiltexture)
    legend(0,0.8+0.05*length(samplenames),legend=samplenames,pch=pch,col=col)
  }

  point<- c(1-soiltexture[,1]+(soiltexture[,1]-(1-soiltexture[,2]))*0.5,soiltexture[,3]*sin60)
  x<- 1-soiltexture[,1]+(soiltexture[,1]-(1-soiltexture[,2]))*0.5
  y<- soiltexture[,3]*sin60
  type_sol<-cbind(x,y)

  # vérifier l'appartenance du point au polygone

   point.in.polygon<-sp::point.in.polygon
  a<-point.in.polygon(x,y,x_clay,y_clay)
  b<-point.in.polygon(x,y,x_clay_loam,y_clay_loam)
  cc<-point.in.polygon(x,y,x_sandy_clay_loam,y_sandy_clay_loam)
  d<-point.in.polygon(x,y,x_sandy_clay,y_sandy_clay)
  e<-point.in.polygon(x,y,x_sandy_loam,y_sandy_loam)
  f<-point.in.polygon(x,y,x_loamy_sand,y_loamy_sand)
  g<-point.in.polygon(x,y,x_loam,y_loam)
  h<-point.in.polygon(x,y,x_silt_loam,y_silt_loam)
  i<-point.in.polygon(x,y,x_silty_clay_loam,y_silty_clay_loam)
  j<-point.in.polygon(x,y,x_silty_clay,y_silty_clay)
  k<-point.in.polygon(x,y,x_sand,y_sand)
  l<-point.in.polygon(x,y,x_silt,y_silt)


  # print(type_sol)
  # print(c(a,b,cc,d,e,f,g,h,i,j,k,l))
  textures<-cbind(type_sol,a,b,cc,d,e,f,g,h,i,j,k,l)
  textures<-as.data.frame(textures)
  names(textures)<-c("xpoint", "ypoint","clay","clay loam","sandy clay loam","sandy clay ",
                     "sandy loam","loamy_sand","loam","silt loam","silty clay loam","silty clay",
                     "sand","silt")
  resultat <-textures
  par(oldpar)
  return(resultat)
}
