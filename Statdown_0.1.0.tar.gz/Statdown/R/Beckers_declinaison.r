#' @title Bec_declin
#'
#' @description This function compute declination using the Beckers method
#'
#'@usage Bec_declin(Jday)
#
#'@param Jday  Vector of  Julian dates or days of the year [day]
#'
#'@return
#'  \item{data.frame}{Day and associated declination}
#'
#'@references B. Beckers, L. Masset & P.Beckers, Rapport Helio_003_fr, 2008, www.heliodon.net
#'
#' @example
#'\dontrun{
#'Jday<-seq(31:60)
#'a<-as.vector(Jday)
#'Bec_declin(a)
#'}
#'
#' @export Bec_declin(Jday)
#'@author LUKABWE KASONGO JOSUE \email{josuelukabwe@gmail.com} and SILMANE TAIBI \email{slimanetaibi@gmail.com}


Bec_declin<-function(Jday){
if(!is.vector(Jday))
stop(paste("Jday must be a vector"))
for(i in Jday){
Bec_declin<-(asin(sin(23.45*pi/180)*sin((360./365 *Jday-81)*pi/180)))*180/pi
}
d<-cbind(Jday,Bec_declin)
d<-as.data.frame(d)
return(d)
}


