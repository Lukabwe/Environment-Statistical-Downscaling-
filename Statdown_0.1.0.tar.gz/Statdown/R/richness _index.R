#' @title richness index
#'
#' @description This function compute the Richness index on the columns of data frame
#'
#' @usage richness(df)
#
#'@param df  Data.frame of data to compute.
#'
#'@return data.frame
#'  \item{richness}{Richness index associated with classes}
#'
#' @example
#'\dontrun{
#'x<-matrix(0:18,nrow = 6)
#'richness (x)
#'
#'#'y<-rpois(10,6)
#'richness(y)
#'}
#'
#' @export richness(df)
#'
#'@author LUKABWE KASONGO JOSUE \email{josuelukabwe@gmail.com} and SILMANE TAIBI \email{slimanetaibi@gmail.com}


richness <- function(df) {
  if(!is.data.frame(df)){
    df <- data.frame(df)
  }
  index <- apply(df, 2, function(i) length(i[i!=0])-1)
  plot.number<-1:nrow(df)
  result<-as.data.frame(index)
  print(" Richness index is :")
  return(result)
}

