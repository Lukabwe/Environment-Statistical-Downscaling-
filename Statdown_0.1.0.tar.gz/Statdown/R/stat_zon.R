#'@title  stat_zone  area statistics
#'
#'@description This function calculates environments area statistics.
#'
#'@usage stat_zone( frast,resolution,coast1,coast2=NULL)
#'
#'@param emprise: sp object to delimit extent of erea
#'@param frast: raster file containing elevation data
#'@param resolution : numeric list with crs units
#'@param coast1 points shape file of coast 1 ,the erea has one coast limit
#'@param coast2 points shape file of coast 2 if the erea has two coasts limits
#'
#'@return data.frame containing the geographicals variables and environments statistics :
#'
#'  \item{ALTITUDE}{Altitude of pixel}
#'  \item{longitude}{The longitude of the buffer zone}
#'  \item{latitude}{The latitude of the buffer zone}
#'
#'  \item{ENVIRONMENTS STATISTICS}
#'
#'If lengths of buffer are 10km, 20km and 50km, the others statistics will be as here :
#'
#'  \item{mean_10km}{The average of a 10km buffer}
#'  \item{mean_20km}{The average of a 20km buffer}
#'  \item{mean_50km}{The average of a 50km buffer}
#'  \item{max_10km}{The maximun  of a 10km buffer}
#'  \item{max_20km}{The maximum of a 20km buffer}
#'  \item{max_50km}{The maximum of a 50km buffer}
#'  \item{min_10km}{The minimun  of a 10km buffer}
#'  \item{min_20km}{The minimum of a 20km buffer}
#'  \item{min_50km}{The minimum of a 50km buffer}
#'  \item{Std_10km}{The standard deviation  of a 10km buffer}
#'  \item{Std_20km}{The standard deviationof a 20km buffer}
#'  \item{Std_50km}{The standard deviation of a 50km buffer}
#'  \item{dsta}{Distance matrix from a point to the sea or the ocean}
#'  \item{dist_a}{Distance from a point to the sea or the ocean}
#'  \item{disti}{Distance matrix from a point to the sea or the ocean}
#'  \item{dist_i}{Minimum of distance from a point to the sea or the ocean}
#'  \item{En_10km}{Minimum slope at 10 km}
#'  \item{En_20km}{Minimum slope at 20 km}
#'  \item{En_50km}{Minimum slope at 50 km}
#'  \item{Eme_10km}{Median slope at 10 km}
#'  \item{Eme_20km}{Median slope at 20 km}
#'  \item{Eme_50km}{Median slope at 50 km}
#'  \item{Em_10km}{Average slope at 10 km}
#'  \item{Em_20km}{Average slope at 20 km}
#'  \item{Em_50km}{Average slope at 50 km}
#'  \item{R_10km}{Roughness slope at 10 km}
#'  \item{R_20km}{Roughness slope at 20 km}
#'  \item{R_50km}{Roughness slope at 50 km}
#'
#'@note The formulas of slopes (Average,minimum,median androughness) are described in
#'the memory of "LUKABWE KASONGO JOSUE,2018"
#'@note select working directory which containing : shape extent files and raster elevation file ,before running
#'
#' @example
#'\dontrun{
#'frast<-"Joviane_data.tif"
#'buffer<-c(10000,20000,50000)
#'resolution<-0.5
#'coast1<-"Joviane_coast_a.shp"
#'stat_zone (frast,resolution,buffer,coast1,coast2=NULL)
#'}
#'
#' @export stat_zone(frast,resolution,buffer,coast1,coast2=NULL)
#'
#' @references End of study engineer's memory of "LUKABWE KASONGO JOSUE,2018"
#' At Institut hydrométéorologique de formation et de recherches, Oran.
#'
#'@author LUKABWE KASONGO JOSUE \email{josuelukabwe@gmail.com} and SILMANE TAIBI \email{slimanetaibi@gmail.com}






# emprise<-"GRILLE1KM_tuiles_RDC"

#frast<-"elev_RDC.tif"
#frast<-"Joviane_data.tif"
#buffer<-c(10000,20000,50000)

#resolution<-0.5
#coast1<-"coast_RDC_gauche_point"
#stat_zone(frast,resolution,buffer,coast1,coast2=NULL)


stat_zone<-function(frast,resolution,buffer,coast1,coast2=NULL){
  datata1<-NULL
  myproj = "+proj=utm +zone=12 +north +ellps=WGS84 +units=m"
require(rgdal)
require(maptools)
require(raster)
  dsn<-"."
  ogrInfo(dsn)
  ogrListLayers(dsn )
  ogrInfo(dsn=dsn,layer=coast1)


  #shpca = readOGR(dsn=dsn,"coast_RDC_gauche_point")
  #shpci = readOGR(dsn=dsn,"coast_RDC_droite_point")
  shpca = readOGR(dsn=dsn,coast1)
  shpca=SpatialPoints(shpca)
  require(raster)
  ras = raster(frast)

  crss<-crs(ras)
  crst<-paste(crss,"+units=m",sep=" ")
  kk<-makegrid(Spatial(bbox=bbox(ras)), nsig = 2, cellsize=resolution)
  shp2<-SpatialPoints(kk)
  crs(shp2)<-crst


  nama=kk
  for(buff in buffer){
    buffkm=as.integer(buff/1000)
    buffkm=paste(buffkm,'km',sep="")
    extract<-raster::extract
    eval(parse(text=paste('mean_',buffkm, ' <-extract(ras,shp2,buffer=',buff,',fun=mean,df=TRUE)',sep="")))
    eval(parse(text=paste('min_',buffkm,' <-extract(ras,shp2,buffer=',buff,',fun=min,df=TRUE)',sep="")))
    eval(parse(text=paste('max_',buffkm,' <-extract(ras,shp2,buffer=',buff,',fun=max,df=TRUE)',sep="")))
    eval(parse(text=paste('Std_',buffkm,' <-extract(ras,shp2,buffer=',buff,',fun=sd,df=TRUE)',sep="")))
    eval(parse(text=paste('mediane_',buffkm,' <-extract(ras,shp2,buffer=',buff,',fun=median,df=TRUE)',sep="")))
    eval(parse(text=paste('Em_',buffkm,' <-(max_',buffkm,'-mean_',buffkm,')/max_',buffkm,sep="")))


    eval(parse(text=paste('Eme_',buffkm,' <-(max_',buffkm,'-mediane_',buffkm,')/max_',buffkm,sep="")))

    eval(parse(text=paste('En_',buffkm,' <-(max_',buffkm,'-min_',buffkm,')/max_',buffkm,sep="")))

    eval(parse(text=paste('R_',buffkm,' <-Std_',buffkm,'/mean_',buffkm,sep="")))


    eval(parse(text=paste('st_data_',buffkm,' <-as.data.frame(cbind(mean_',buffkm,'[,2],max_',buffkm,'[,2],min_',buffkm,'[,2],Std_',buffkm,'[,2],mediane_',buffkm,'[,2],En_',buffkm,'[,2],Em_',buffkm,'[,2],Eme_',buffkm,'[,2],R_',buffkm,'[,2]))',sep="")))
    eval(parse(text=paste("names(st_data_",buffkm,") <-c('mean_",buffkm,"',","'max_",buffkm,"',","'min_",buffkm,"',","'Std_",buffkm,"',","'mediane_",buffkm,"',","'En_",buffkm,"',","'Em_",buffkm,"',","'Eme_",buffkm,"',","'R_",buffkm,"')",sep="")))

    eval(parse(text=paste('ll<-st_data_',buffkm,sep="")))
   nama<-as.data.frame(cbind(nama,ll))
    }
  rr1=extract(ras,shp2,buffer=1,fun=mean,df=TRUE)
  # names(rr1)<-"ALTITUDE"
  colnames(rr1)<-c("ID","ALTITUDE")
  dsta <- pointDistance(kk, shpca,lonlat=TRUE)
  dist_a<-apply(dsta,1,min)
  if(! is.null(coast2)){
  shpci = readOGR(dsn=dsn,coast2)
  dsti <- pointDistance(kk, shpci,lonlat=TRUE)
  dist_i<-apply(dsti,1,min)
  datazz<-dist_i
  st_data<-as.data.frame(datazz)

  return(st_data)
  }
  lengt<-length(nama[1,])
  io<-nama[,1:2]
  names(io)=c('longitude','latitude')
  datazz<-cbind(rr1,io,dist_a,as.data.frame(nama[,3:lengt]))
  st_data<-as.data.frame(datazz)

  return(st_data)


}

