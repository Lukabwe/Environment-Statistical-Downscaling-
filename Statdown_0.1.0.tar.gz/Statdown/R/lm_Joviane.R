#'Fixation du repertoire de travail
#'setwd("F:/DATA/REGRESSION_HORI")
#'@title   lm_joviane
#'
#' @description This function compute downscaled data
#'
#' @usage  lm_joviane(v,v1,vari,experimente,predictants)
#'
#'@param v Data file containing weather and environments datas with the large resolution "eg 50 km or 0.44°"
#'@param v1 Data file containing environments datas with the fine resolution "eg 1 km or 0.0083°"
#'@param vari  Weather variable to downscal ;accept unique or multiple characters
#'@param experimente Names character  of CMIP5 experiment and time
#'@param predictants Vector containing names of environments variables
#'
#'@return data.frame containing the following structure in horizontal :
#'
#'  \item{v1}{Data file containing environments datas with the fine resolution (eg 1 km)}
#'  \item{vari}{Weather variable downscaled at fine résolution}
#'
#' @details  This function uses the transfer functions to downscal weather data.
#' See more the reference.
#'
#'@export lm_joviane(vari,experimente,predictants,v,v1)
#'
#' @references End of study engineer's memory of "LUKABWE KASONGO JOSUE,2018"
#' At Institut hydrométéorologique de formation et de recherches, Oran.
#'
#'@examples
#'\dontrun{
#'lm_joviane(v,v1,vari,experimente,predictants)
#'}
#'
#' @author LUKABWE KASONGO JOSUE \email{josuelukabwe@gmail.com} and SILMANE TAIBI \email{slimanetaibi@gmail.com}
#'
#'
lm_joviane<- function (v,v1,vari,experimente,predictants){
liste_vari<-vari
noms =list(predictants)

predictant<-function(liste){
  a<-lapply(liste, FUN=paste,collapse = "+")
   return(a)
}

liste_mois<-c("jan","fev","mar","avr","mai","jun","jul","aou","sep","oct","nov","dec")
b<-"backward"
c<-"confidence"
i=0
j=0
k=0


gh<-NULL
vvp<-NULL



#fichier<-file.choose()
uu<-NULL
  vvp<-NULL
  eval(parse(text=paste('vv','<-NULL', sep='')))


  predict_noms<-predictant(noms)
    for (vari in liste_vari){
      for(mois in liste_mois){


        eval(parse(text=paste("lmMin_",mois,"  <- lm(",vari,"_",mois,"_h","~1,data=","v)", sep='')))
        # lmMin_jan <- lm(tas_jan~1,data=v)
        eval(parse(text=paste("lmMax_",mois,"  <- lm(",vari,"_",mois,"_h","~",predict_noms,',data=',"v)", sep='')))
        # lmMax1  <- lm(tas_jan ~ latitude+longitude+ALTITUDE+E+depth.10.S+log_dist_a+log_dist_i+min_10km+max_10km+
        #mean_10km+Std_10km+min_50km+max_50km+mean_50km+Std_50km+min_20km+max_20km+mean_20km+Std_20km+R_50km+
        #En_50km+Em_50km+Eme_50km+R_20km+En_20km+Em_20km+Eme_20km+R_10km+En_10km+Em_10km+Eme_10km+TY_veg,data=v)


        eval(parse(text=paste('h_lm_',mois,' <-step(',"lmMax_",mois,',scope=list(lower=',"lmMin_",mois,"),trace=0,direction=","'",b,"')", sep='')))
        eval(parse(text=paste('h_',mois,'<-predict(','h_lm_',mois,',v1',",interval =","'",c,"',level=0.80)", sep='')))



        eval(parse(text= paste('vm','<-','unname(h_',mois,'[,1])',sep='')))





       vvp <- as.data.frame(cbind(vvp,eval(parse(text= paste(vari,"_",mois,'=vm',sep="")))))


       u=paste(vari,"_",mois,sep="")

       uu<-c(uu,u)

      }
    }

nn=c(names(v1),uu)
print(nn)

  eval(parse(text=paste('vv','<-cbind(v1',',vvp)', sep='')))
  names(vv)=nn
 eval(parse(text=paste("write.table(vv",",'",'reg_',experimente,".csv',","sep=","';',row.names=F)", sep='')))
 vv<-as.data.frame(vv)
 return(vv)
 }


