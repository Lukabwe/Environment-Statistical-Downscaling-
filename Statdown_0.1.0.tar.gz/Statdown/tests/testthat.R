library(testthat)
library(Joviane)

test_check("Joviane")
